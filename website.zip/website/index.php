<?php
require 'connect.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>My personal || website</title>
	<!--custom css link-->
	<link rel="shortcut icon" href="img/img-11.jpg" type="image/x-icon">
  <link rel="stylesheet" type="text/css" href="style.css">
	<!--box icons link-->
	<link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
<!--font link-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<!--google fonts link-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<!--header-->
<header>
	<a href="#" class="logo">RTM</a>
	<ul class="navbar">
		<li><a href="#">Home</a></li>
		<li><a href="about.php">About</a></li>
		<li><a href="services.php">Services</a></li>
		<li><a href="contact.php">Contact</a></li>
	</ul>
	<div class="h-right">
		<a href="#">Follow us</a>
		<a href="https://www.facebook.com/rupesh.thapamagar.501"><i class="ri-facebook-fill"></i></a>
		<a href="https://www.youtube.com/@rupeshmagar6407"><i class="ri-youtube-fill"></i></a>
		<div class="bx bx-menu" id="menu-icon"></div>
	</div>
</header>

<!--home section design-->
<section class="home">
	<div class="home-text">
		<h1>Welcome  <br>To My website</h1>
		<p>Welcome to this website for anyone visiting there. I hope, <br>all are happy and enjoy while visiting this site. Thank you!!</p>
		<a href="click-me.php" class="btn">Click Me</a>
	</div>
</section>

<!--feature section design-->
<section class="feature">
	<marquee behavior="scroll" onmouseover="stop();" onmouseout="start();">
	<div class="feature-content">
		<div class="row">
			<div class="row-img">
				<img src="img/img-16.jpg">
			</div>
		</div>
		<div class="row">
			<div class="row-img">
				<img src="img/img-6.jpg">
			</div>
		</div>
		<div class="row">
			<div class="row-img">
				<img src="img/img-17.jpg">
			</div>
		</div>
		<div class="row">
			<div class="row-img">
				<img src="img/img-11.jpg">
			</div>
		</div>
		<div class="row">
			<div class="row-img">
				<img src="img/img-14.jpg">
			</div>
		</div>
	</div>
</marquee>
</section>
<hr>
<!--- holiday section design-->
<section class="holiday">
	<div class="holiday-img">
		<img src="img/img-7.jpg">
	</div>
	<div class="holiday-text">
	<h2>Journey of <span style="color:yellow;">basic website</span> designing</h2>
	<p style="text-align:justify;">I am IT student who has completed diploma. I want to become a sucessful 
	website designer in the future. When I joined in diploma IT engineer. I wanted to learn website design.
	SO, I started learning HTML, CSS, Js and PHP, SQL. I was trying to understand about basic tags for the 
	first time. Then started searching on YouTube, Google. Also started learning JavaScript, PHP<span id="dots_2">....</span><span id="more_2">, SQL and 
	CSS. After some time, I learned to created newsportal website from wordpress and blogger site. This is 
	how my website design Journey began-:)</span></p>
		<button onclick="myFunction_2()" id="myBtn_2" class="btn">Read more</button>
	</div>
</section>

<!--- tour section design-->
<section class="tour">
	<div class="center-text">
		<h2>Popular <span style="color:#9f1010;">Gallery</span></h2>
		<span class="text-underline"></span>
	</div>
	<div class="tour-content">
		<div class="box">
			<img src="img/image-1.jpg">
			<h6>Patan Museum</h6>
			<h4>Patan durbar</h4>
		</div>
		<div class="box">
			<img src="img/image-16.jpg">
			<h6>Patan Museum</h6>
			<h4>Patan durbar</h4>
		</div>
		
		<div class="box">
			<img src="img/image-14.jpg">
			<h6>Patan Museum</h6>
			<h4>Patan durbar</h4>
		</div>
	</div>
	<div class="center-btn">
		<a href="image.php" class="btn">View More</a>
	</div>
</section>

<!--- culture section design-->
<section class="culture">
	<div class="culture-text">
		<h2>My <span style="color:green;">Dream</span></h2>
		<p style="text-align:justify;">Everyone wants to be successful and rich. I also dream of becoming 
		successful in the field i choose although i am still indecisive about the career path i will choose. 
		But i know whatever i choose i will work hard, stay focused i choose field and dream. We dream about
		 <span id="dots_1">....</span><span id="more_1">  change and improvement, we set goals, seemingly impossible goals, when we will reach our goals, when 
		 our lives will change for the better.</span></p>
		<button onclick="myFunction_1()" id="myBtn_1" class="btn">Read more</button>
	</div>
	<div class="culture-img">
		<img src="img/img-3.jpg">
	</div>
</section>
<!-- swal('Successfully','Your data saved','success'); -->
<!--- newsletter section design-->
<section class="newsletter">
	<div class="newsletter-content">
		<div class="newsletter-text">
			<h2>Ready to explorer?</h2>
			<p>Let's go on vacation, make your day</p>
		</div>
		<form method="post">
			<input type="email" name="email" placeholder="Enter your email....." oninput="setCustomValidity('')" oninvalid="setCustomValidity('Enter your gmail Id')"   required>
			<input type="submit" value="Submit" name="submit"  class="btn" >
		</form>
	</div>
</section>
<!--- footer section design-->
<section class="footer">
	<div class="footer-box">
		<h3>Location</h3>
		<a href="https://goo.gl/maps/y5AMcz2qofVa4vH49">Sindhupalchowk,Bahrabise</a>
		<a href="tel:9860243277">+977 9860243277</a>
	</div>
	<div class="footer-box">
		<h3>Quick Link</h3>
		<a href="about.php">About</a>
		<a href="services.php">Services</a>
		<a href="contact.php">Contact</a>
	</div>
	<div class="footer-box">
		<h3>Email</h3>
		<a href="mailto:">rupeshmagar1365@gmail.com</a>
	</div>
		<div class="footer-box">
		<h3>Social</h3>
		<div class="social">
		<a href="sms:9860243277?body=Thank You"><i class="ri-message-fill"></i></a>
		<a href="https://www.facebook.com/rupesh.thapamagar.501"><i class="ri-facebook-fill"></i></a>
		<a href="https://www.youtube.com/@rupeshmagar6407"><i class="ri-youtube-fill"></i></a>
		</div>
	</div>
</section>
<!--- copyright-->
<div class="copyright">
	<p>Copyright@2024 By | RTM |</p>
</div>
<!--- custom js file link-->
<script src="script.js"></script>
<script src="script-1.js"></script>
</body>
</html>